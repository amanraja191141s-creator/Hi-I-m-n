# SA Calculator Tools Only v100.26

## Unit Converter video-parity correction
- Rebuilt Unit Converter source/result controls as compact single compound rows.
- Amount/result stays on the left; functional unit selector stays on the right.
- Removed nested selector borders and duplicate row frames.
- Reduced swap control to the compact centered control shown in the supplied recording.
- Removed decorative category glyph from the selected tool title.
- Preserved category chooser/workspace navigation, unit selection, swap behavior, live conversion, and existing conversion factors.
- Kept the hidden category select as an internal state carrier; it is not a visible duplicate control.

## Release identity
- App version: 2.0.24-v100.26
- Android versionCode: 1099166

## Local verification
- `npm run build:web`: passed; 18 Android web assets verified.
- `npm run test:release`: 5 focused Unit Converter regression tests passed.
- `node --check`: app.js, server.js, service-worker.js passed.
- Workflow YAML parsed successfully.
- Embedded and standalone workflow copies are identical.
- Source and generated Android web assets checked byte-for-byte.
- ZIP archive integrity checked.

A GitHub-hosted Android build and physical-device visual verification remain pending.
