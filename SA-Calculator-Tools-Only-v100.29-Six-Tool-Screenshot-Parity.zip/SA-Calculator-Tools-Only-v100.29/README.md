# SA Calculator — Tools Only v100.10

This is the tools-only release containing 12 tool workspaces in three categories. The shared numeric keypad and calculation engine remain as internal dependencies.

## Android APK build
The GitHub Actions workflow is `.github/workflows/main.yml`. It uses the runner-preinstalled Android SDK rather than `android-actions/setup-android@v3`, because the supplied failed run shows that action invoking the removed `sdkmanager tools` package.

The workflow installs only:
- `platform-tools`
- `platforms;android-35`
- `build-tools;35.0.0`

It then installs pinned Capacitor 7.4.3 dependencies, runs regression tests, generates/synchronizes the Android project, applies native branding and insets, builds `assembleDebug`, verifies package metadata, and uploads the APK artifact.

## Run locally
- Node.js 22
- `npm install --no-package-lock`
- `npm run test:release`
- `npm run android:setup`
- `cd android && ./gradlew assembleDebug`


## v100.16 UI update
All 12 tool screens now share the Loan-reference field frame (76px outer height, 10px radius, 15px inset, stacked label/value and blue active outline). Compound selectors, date pickers, quick rates, tabs, calculation handlers, result panels and keypad behavior remain separate and preserved. See `RELEASE-NOTES-v100.16.md`.


## v100.19 recording-driven correction
A final-loaded field parity stylesheet now forces editable values to stretch to the full field width across all 12 tools, while retaining compound selectors and each tool's existing calculations and result systems. Release metadata is synchronized across HTML, JavaScript, package, manifest and workflow. See `RELEASE-NOTES-v100.19.md`.


## Android CI build performance (v100.19)
The GitHub Actions workflow caches npm downloads and Gradle dependencies/build outputs, enables Gradle incremental/build-cache execution with two workers, and skips recompression of the APK artifact. The first clean build still downloads dependencies; subsequent compatible runs can reuse the cache.


## Current release — v100.28
- App version: `2.0.26-v100.28`
- Android versionCode: `1099168`
- Final device parity stylesheet: `assets/css/final-device-parity-v10028.css`
