# v100.26 — Recording-driven layout corrections

## Confirmed issues addressed
- Removed the duplicate Percentage mode dropdown from the visible layout while retaining its DOM value as the JavaScript synchronization source.
- Hid the legacy Unit Category dropdown from the visible workspace while retaining the select element for category data binding.
- Scoped 60px input geometry to actual editable field containers; computed result rows are no longer treated as input frames.
- Kept Unit Converter source/target rows as two-column compound controls.
- Preserved currency selectors, GST mode/rate/place controls, BMI unit switches, Loan icons and all calculation handlers.
- Kept keypad dock responsive and ensured scrollable workspaces reserve space while the keypad is active.
- Updated service-worker cache identity and Android web asset preparation.

## Release identity
- App version: `2.0.22-v100.26`
- Android versionCode: `1099166`
