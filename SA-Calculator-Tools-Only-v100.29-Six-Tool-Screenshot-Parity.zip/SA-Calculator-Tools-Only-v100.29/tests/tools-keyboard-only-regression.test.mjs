import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const allowed=['currencies','units','salestax','loan','savings','salary','tip','sip','discount','percent','agecalc','bodymetrics'];
const removed=['date','fuelcost','fuelefficiency','gradeavg','hex','unitprice','worldtime'];
test('exactly the requested 12 tool workspaces are present and populated',()=>{
  for(const id of allowed){
    const start=html.indexOf(`id="screen-${id}"`);
    assert.ok(start>=0,`missing screen-${id}`);
    const next=[html.indexOf('<div class="screen"',start+1),html.indexOf('<section class="screen',start+1)].filter(x=>x>=0);
    const block=html.slice(start,next.length?Math.min(...next):html.length);
    assert.doesNotMatch(block,/data-tool-surface-removed=["']true["']/);
    assert.match(block,/<(?:input|select|button|form)\b|class=[\"']input-val-box[\"']/i,`screen-${id} has no interactive controls`);
  }
  for(const id of removed) assert.doesNotMatch(html,new RegExp(`id=["']screen-${id}["']`),`removed screen-${id} remains`);
});
test('tool launcher exposes exactly the requested 12 destinations',()=>{
  const ids=[...html.matchAll(/data-tool-screen=[\"']([^\"']+)[\"']/g)].map(x=>x[1]);
  assert.equal(ids.length,12); assert.deepEqual([...ids].sort(),[...allowed].sort());
});
test('favorites and search operate from the same 12-item registry',()=>{
  assert.match(html,/id=[\"']favorites-screen-list[\"']/);
  assert.match(html,/id=[\"']tools-screen-search[\"']/);
  const start=app.indexOf('const ALL_CALC_ITEMS = [');
  const end=app.indexOf('];',start);
  assert.ok(start>=0&&end>start);
  const registry=app.slice(start,end);
  for(const id of allowed) assert.match(registry,new RegExp(`id: [\"']${id}[\"']`));
  for(const id of removed) assert.doesNotMatch(registry,new RegExp(`id: [\"']${id}[\"']`));
});
test('shared numeric keypad remains available to all retained numeric tool screens',()=>{
  assert.match(html,/id=[\"']tool-keypad-dock[\"']/);
  for(const key of ['7','8','9','CLR','4','5','6','DEL','1','2','3','EQUAL','00','0','.']) assert.match(html,new RegExp(`data-tool-key=[\"']${key}[\"']`));
  assert.match(app,/function initKeypads\(\)/);
  assert.match(app,/document\.querySelectorAll\('\[data-tool-key\]'\)/);
  assert.match(app,/initCurrencies\(\);/); assert.match(app,/initUnits\(\);/);
});
test('removed tools are not initialized or scheduled at startup',()=>{
  const init=app.slice(app.indexOf("document.addEventListener('DOMContentLoaded', () => {"));
  const body=init.slice(0,init.indexOf('});')+3);
  for(const call of ['initDateEvents();','initGpaCourses();','initWorldTime();','updateWorldTimeLive();']) assert.doesNotMatch(body,new RegExp(call.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
});
