import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const app=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/unit-video-parity-v10026.css','utf8');
test('unit converter compound rows retain amount, selectors, result and swap controls',()=>{
 for(const id of ['unit-from','unit-to','unit-input-val','unit-result-val','btn-unit-swap']) assert.ok(html.includes(`id="${id}"`));
 assert.ok(css.includes('display:flex !important'));
 assert.ok(css.includes('width:20px !important'));
});
test('unit category navigation and swap behavior remain wired',()=>{
 for(const snippet of ['chooser.hidden = false','workspace.hidden = true','workspace.hidden = false',"catSel.dispatchEvent(new Event('change'","f.value = toValue;","t.value = fromValue;"]) assert.ok(app.includes(snippet),snippet);
});
test('unit title uses visible category label without decorative icon',()=>{
 assert.ok(app.includes("selectedTile?.querySelector('span:last-child')"));
});
test('volume conversion retains exact US gallon factor',()=>{
 assert.ok(app.includes("'US liquid gallon (gal)': 3.785411784"));
});
test('responsive compact row and hidden legacy category are enforced',()=>{
 assert.ok(css.includes('@media (max-width:360px)'));
 assert.ok(html.includes('class="tool-input-group unit-category-state" hidden'));
});
