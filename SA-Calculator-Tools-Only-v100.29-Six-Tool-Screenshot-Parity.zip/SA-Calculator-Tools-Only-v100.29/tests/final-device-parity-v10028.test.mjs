import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p,'utf8');
const html=read('index.html'), css=read('assets/css/final-device-parity-v10028.css'), latestCss=read('assets/css/final-device-parity-v10029.css');
const app=read('assets/js/app.js'), pkg=JSON.parse(read('package.json'));
const sw=read('service-worker.js'), build=read('scripts/prepare-android-web.mjs');
const workflow=read('.github/workflows/main.yml');
test('v100.28 release metadata and service-worker namespace are synchronized',()=>{
 assert.equal(pkg.version,'2.0.27-v100.29'); assert.equal(pkg.androidVersionCode,1099169);
 assert.match(html,/2\.0\.27-v100\.29/); assert.match(sw,/sa-calculator-tools-only-v10029/);
 assert.match(sw,/final-device-parity-v10028\.css/);
});
test('final device stylesheet is last, required and precached for Android',()=>{
 assert.ok(html.indexOf('assets/css/final-device-parity-v10029.css')>html.indexOf('assets/css/final-device-parity-v10028.css'));
 assert.match(build,/assets\/css\/final-device-parity-v10028\.css/);
 assert.match(sw,/\.\/assets\/css\/final-device-parity-v10028\.css/);
});
test('Historical v100.28 Unit Converter layout remains preserved as a regression fixture',()=>{
 assert.match(css,/grid-template-rows:minmax\(0,1fr\) 30px/);
 assert.match(css,/height:120px !important/);
 assert.match(css,/\.unit-select-wrap \{[\s\S]*?grid-row:2/);
 assert.match(css,/\.input-row > \.input-val-box,[\s\S]*?grid-row:1/);
 assert.match(css,/btn-unit-swap[\s\S]*?width:42px/);
 for(const id of ['unit-from','unit-to','unit-input-val','unit-result-val','btn-unit-swap']) assert.ok(html.includes(`id="${id}"`));
 assert.match(app,/f\.value = toValue;[\s\S]*t\.value = fromValue;/);
});
test('BMI unit toggles remain attached to fields and v100.29 removes obsolete visual layers',()=>{
 assert.equal((html.match(/class="bmi-reference-control"/g)||[]).length,2);
 assert.match(html,/bmi-reference-control[\s\S]*?data-bmi-weight-unit="kg"[\s\S]*?<\/div>[\s\S]*?bmi-reference-control[\s\S]*?data-bmi-height-unit="cm"/);
 assert.match(css,/\.bmi-reference-control \.bmi-unit-switch\s*\{[\s\S]*?position:absolute/); assert.match(latestCss,/\.bmi-unit-switch\{position:static/);
 assert.match(css,/\.bmi-legacy-fields > \.select-box[\s\S]*?background-color:#303744/);
 assert.doesNotMatch(html,/aria-hidden="true" class="body-metrics-grid bmi-legacy-fields"/);
 assert.match(app,/data-bmi-weight-unit/); assert.match(app,/data-bmi-height-unit/);
});
test('SIP inactive panel and every hidden native control remain non-rendering',()=>{
 assert.match(css,/\[hidden\]\s*\{\s*display:none !important/);
 assert.match(html,/<section[^>]*hidden=""[^>]*id="sip-delay-panel"/);
 assert.match(app,/delayed\.hidden = !delayMode/);
});
test('workflow expects v100.29 and uploads verified absolute APK path',()=>{
 assert.match(workflow,/SA-Calculator-Tools-Only-v100\.29\*\.zip/);
 assert.match(workflow,/expected='2\.0\.27-v100\.29'/);
 assert.match(workflow,/1099169/); assert.match(workflow,/path:\s*\$\{\{ env\.APK_PATH \}\}/);
 assert.equal(workflow,read('sa-calculator-tools-only-v100.29.yml'));
});
