import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const html=read('index.html'), css=read('assets/css/final-device-parity-v10029.css');
const app=read('assets/js/app.js'), pkg=JSON.parse(read('package.json'));
const prep=read('scripts/prepare-android-web.mjs'), sw=read('service-worker.js');
const workflow=read('.github/workflows/main.yml');
test('v100.29 release identity and final UI layer are synchronized',()=>{
 assert.equal(pkg.version,'2.0.27-v100.29'); assert.equal(pkg.androidVersionCode,1099169);
 assert.ok(html.indexOf('assets/css/final-device-parity-v10029.css')>html.indexOf('assets/css/final-device-parity-v10028.css'));
 assert.match(prep,/final-device-parity-v10029\.css/); assert.match(sw,/final-device-parity-v10029\.css/);
 assert.match(sw,/sa-calculator-tools-only-v10029/); assert.equal(workflow,read('sa-calculator-tools-only-v100.29.yml'));
});
test('six screenshot targets retain their required live controls and calculation wiring',()=>{
 for(const id of ['screen-sip','screen-discount','screen-percent','screen-units','screen-agecalc','screen-bodymetrics']) assert.ok(html.includes(`id="${id}"`));
 for(const id of ['sip-tab-calculator','sip-tab-delay','disc-orig','disc-pct','pct-y','pct-x','unit-from','unit-to','unit-input-val','unit-result-val','btn-unit-swap','age-date-of-birth','age-calculate','bmi-weight','bmi-height']) assert.ok(html.includes(`id="${id}"`),`missing ${id}`);
 for(const token of ['data-bmi-weight-unit','data-bmi-height-unit','sip-delay-panel']) assert.ok(html.includes(token));
 assert.match(app,/data-bmi-weight-unit/); assert.match(app,/data-bmi-height-unit/);
});
test('v100.29 removes extra visible layers while preserving responsive field geometry',()=>{
 assert.match(css,/\.sip-video-tabs \[role=tab\][\s\S]*?height:84px/);
 assert.match(css,/\.discount-result-row\{display:none/);
 assert.match(css,/\.percent-mode-tabs[\s\S]*?display:none/);
 assert.match(css,/\.unit-select-wrap[\s\S]*?flex:0 1 42%/);
 assert.match(css,/btn-unit-swap[\s\S]*?width:58px/);
 assert.match(css,/\.bmi-legacy-fields\{display:none/);
 assert.match(css,/@media\(max-width:380px\)/);
});
