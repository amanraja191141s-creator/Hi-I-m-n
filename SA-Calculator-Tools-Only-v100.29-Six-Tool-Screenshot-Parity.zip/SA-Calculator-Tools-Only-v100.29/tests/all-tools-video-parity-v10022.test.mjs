import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read=(p)=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('v100.24 loads the final all-tools video parity layer after legacy styles',()=>{
 const h=read('index.html');
 const a=h.indexOf('assets/css/screen-parity-v10020.css');
 const b=h.indexOf('assets/css/all-tools-video-parity-v10022.css');
 const c=h.indexOf('assets/css/all-tools-video-parity-v10025.css'); assert.ok(a>=0&&b>a&&c>b);
});
test('v100.23 applies the video reference geometry to every numeric tool screen',()=>{
 const c=read('assets/css/all-tools-video-parity-v10022.css');
 for(const id of ['salestax','loan','savings','salary','tip','sip','discount','percent','currencies','units','agecalc','bodymetrics']) assert.match(c,new RegExp(`#screen-${id}`));
 assert.match(c,/height:\s*60px/); assert.match(c,/border-radius:\s*8px/); assert.match(c,/border-radius:\s*50%/);
 assert.match(c,/--sa-v22-key-size/); assert.match(c,/reference-screen-more/);
});
test('v100.23 keeps compound selectors and unit category navigation usable',()=>{
 const c=read('assets/css/all-tools-video-parity-v10022.css');
 for(const x of ['.currency-reference-select','.unit-select-wrap','.bmi-unit-switch','.gst-quick-rates','.reference-period-unit','.sip-video-tabs','.age-dob-field']) assert.ok(c.includes(x),x);
 assert.match(c,/#screen-viewport #screen-units \.unit-category-chooser/);
});
