import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css=readFileSync(new URL('../assets/css/tool-reference-ui.css',import.meta.url),'utf8');
const prod=readFileSync(new URL('../www/assets/css/tool-reference-ui.css',import.meta.url),'utf8');
const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
test('v100.16 uses the shared 76px Loan reference field frame across all tools',()=>{
 const marker=css.lastIndexOf('v100.13 — restore the reference recording'); assert.ok(marker>0);
 const layer=css.slice(marker);
 for(const token of ['min-height:76px !important','height:76px !important','border-radius:10px !important','padding:10px 15px !important','border:0 !important']) assert.ok(layer.includes(token),`missing ${token}`);
 assert.match(layer,/v100\.16 — one shared Loan-reference field system across every tool/);
});
test('production stylesheet is identical and loaded',()=>{assert.equal(prod,css);assert.match(html,/assets\/css\/tool-reference-ui\.css/)});
test('all twelve tool launchers and core input targets remain',()=>{
 const ids=[...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m=>m[1]); assert.equal(new Set(ids).size,12);
 for(const id of ['loan-p','loan-r','loan-tenure','tax-orig','tax-rate','salary-gross','sav-p','sip-monthly','tip-bill','cur-amount','disc-orig','pct-y','unit-input-val','bmi-weight']) assert.ok(html.includes(`id="${id}"`),`missing ${id}`);
});
