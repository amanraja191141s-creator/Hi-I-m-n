import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/all-tools-video-parity-v10023.css','utf8');
const finalCss=fs.readFileSync('assets/css/final-device-parity-v10028.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const prep=fs.readFileSync('scripts/prepare-android-web.mjs','utf8');
const sw=fs.readFileSync('service-worker.js','utf8');
test('v100.23 release identity and Android bundle include final parity layer',()=>{
 assert.ok(pkg.version.endsWith('v100.29')); 
 assert.equal(pkg.androidVersionCode,1099169);
 assert.match(html,/all-tools-video-parity-v10023\.css/);
 assert.match(prep,/all-tools-video-parity-v10023\.css/);
 assert.match(sw,/all-tools-video-parity-v10023\.css/);
});
test('hidden tool panels and native duplicate percentage selector cannot be resurrected',()=>{
 assert.match(css,/\[hidden\][^{]*\{display:none!important;/);
 assert.match(css,/#screen-percent \.percent-reference-mode\{display:none!important;/);
});
test('currency fields and unit conversion rows have explicit responsive geometry',()=>{
 for(const selector of ['.currency-reference-entry','.currency-reference-select','#unit-converter-workspace .input-row','.unit-category-state[hidden]'])
   assert.ok(css.includes(selector),`missing ${selector}`);
});
test('BMI units remain visible and aligned with their corresponding input field',()=>{
 assert.match(finalCss,/\.bmi-reference-control \.bmi-unit-switch\s*\{[\s\S]*?position:absolute/);
});
test('all 12 tool launchers remain present',()=>{
 const ids=[...html.matchAll(/class="tool-launch-item"[^>]*data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
 assert.equal(ids.length,12); assert.equal(new Set(ids).size,12);
});
