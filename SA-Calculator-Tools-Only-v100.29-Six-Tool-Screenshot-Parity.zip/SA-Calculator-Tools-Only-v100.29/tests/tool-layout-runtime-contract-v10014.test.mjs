import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('v100.15 uses one stacked Loan-reference field shell across all tool workspaces',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/v100\.15 — structural tool-form repair/);
 assert.match(css,/--sa-field-height:\s*52px/);
 assert.match(css,/\.reference-field,\s*\.input-row,\s*\.tool-data-row/);
 assert.match(css,/flex-direction:\s*column\s*!important/);
 assert.match(css,/\.loan-video-form > \.tool-field-row/);
 assert.match(css,/\.currency-reference-entry/);
 assert.match(css,/\.gst-rate-entry-row/);
 assert.match(css,/\.bmi-reference-field-main/);
});
test('v100.15 keeps compound selectors and result rows separate from editable field shells',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/#screen-units \.input-row\s*\{\s*display:flex/);
 assert.match(css,/#screen-currencies \.tool-field-row\s*\{\s*display:flex/);
 assert.match(css,/discount-result-row/);
 assert.match(css,/sip-video-tabs/);
 assert.match(css,/reference-period-unit/);
});
test('v100.15 keeps screen toolbar visible and scroll area independently scrollable',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/\.reference-screen-toolbar\s*\{[\s\S]*?flex:\s*0 0 52px/);
 assert.match(css,/\.calc-scrollable,[\s\S]*?overflow-y:\s*auto/);
});
test('release metadata is v100.23 and APK artifact path remains absolute',()=>{
 const p=JSON.parse(read('package.json')); const m=JSON.parse(read('manifest.webmanifest'));
 assert.equal(p.version,'2.0.27-v100.29'); assert.equal(p.androidVersionCode,1099169); assert.equal(m.version,p.version);
 const y=read('.github/workflows/main.yml');
 assert.match(y,/expected='2\.0\.27-v100\.29'/); assert.match(y,/versionCode='1099169'/); assert.match(y,/path:\s*\$\{\{ env\.APK_PATH \}\}/);
});
