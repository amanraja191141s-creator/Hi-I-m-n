import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const css=fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
test('v100.16 applies one 76px Loan-reference field geometry to every calculator tool',()=>{
  assert.match(css,/v100\.16 — one shared Loan-reference field system across every tool/);
  for(const id of ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics']) {
    assert.ok(html.includes(`id="screen-${id}"`),`missing tool ${id}`);
  }
  for(const token of ['min-height:76px !important','height:76px !important','border-radius:10px !important','padding:10px 15px !important','font-size:18px !important']) assert.ok(css.includes(token),`missing ${token}`);
  assert.match(css,/#screen-viewport #screen-loan \.loan-video-form > \.tool-field-row/);
  assert.match(css,/#screen-viewport #screen-currencies \.tool-field-row/);
  assert.match(css,/#screen-viewport #screen-units \.input-row/);
  assert.match(css,/#screen-viewport #screen-agecalc \.age-dob-field/);
  assert.match(css,/#screen-viewport #screen-bodymetrics \.bmi-reference-field/);
});
test('v100.16 keeps compound selectors, result rows and picker controls distinct',()=>{
  assert.match(css,/#screen-viewport #screen-units \.input-row \.select-box/);
  assert.match(css,/#screen-viewport #screen-currencies \.currency-code-select/);
  assert.match(css,/#screen-viewport #screen-salestax \.gst-quick-rates button/);
  assert.match(css,/#screen-viewport #screen-discount \.tool-data-row:not\(\.discount-result-row\)/);
  assert.match(css,/#screen-loan \.loan-tenure-picker\[hidden\]/);
});
