import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('native hidden attribute is authoritative for every tool and overlay',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/\[hidden\][\s\S]{0,160}display:\s*none\s*!important/);
 assert.match(css,/#screen-viewport \[hidden\]/);
 assert.match(css,/#tool-keypad-dock\[hidden\]/);
});
test('loan tenure picker is hidden at rest and has an explicit opened-dialog layout',()=>{
 const html=read('index.html'); const picker=html.match(/<div[^>]*class="loan-tenure-picker"[^>]*hidden(?:="")?[^>]*id="loan-tenure-picker"[^>]*>/);
 assert.ok(picker,'loan picker must start hidden');
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/#screen-loan \.loan-tenure-picker:not\(\[hidden\]\)/);
 assert.match(css,/loan-tenure-picker-dialog/);
});
test('all tool stylesheets use the same hidden-layer protection in Android web bundle',()=>{
 const build=read('scripts/prepare-android-web.mjs');
 assert.match(build,/assets\/css\/tool-reference-ui\.css/);
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/\[hidden\][\s\S]*display:\s*none\s*!important/);
});

test('loan picker and hidden tool layers remain hidden until explicitly opened',()=>{ const html=read('index.html'); assert.match(html,/class=\"loan-tenure-picker\" hidden=\"\"/); const css=read('assets/css/tool-reference-ui.css'); assert.match(css,/#screen-viewport #screen-loan \.loan-tenure-picker\[hidden\]\s*\{\s*display:none !important/); });
