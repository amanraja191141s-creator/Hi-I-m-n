import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const workflow=fs.readFileSync(new URL('../.github/workflows/main.yml',import.meta.url),'utf8');
test('v100.23 workflow prioritizes the uploaded release ZIP over stale checked-out package.json',()=>{
  assert.match(workflow,/uploaded release ZIP is authoritative/);
  assert.match(workflow,/-name 'SA-Calculator-Tools-Only-v100\.29\*\.zip'/);
  assert.match(workflow,/SEARCH_ROOT="\$EXTRACT_DIR"/);
  assert.match(workflow,/Using uploaded release archive/);
  assert.match(workflow,/No release ZIP found; using checked-out project files as fallback/);
  assert.ok(workflow.indexOf('uploaded release ZIP is authoritative') < workflow.indexOf('Set up Node.js 22'));
});
test('v100.23 release identity failure reports actual and expected metadata',()=>{
  assert.match(workflow,/Release identity mismatch: found name=/);
  assert.match(workflow,/androidVersionCode=\$\{p\.androidVersionCode\}/);
});
