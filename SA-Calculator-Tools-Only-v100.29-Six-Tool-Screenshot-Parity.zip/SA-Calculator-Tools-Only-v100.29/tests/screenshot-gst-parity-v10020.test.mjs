import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('GST reference layout keeps all four original working mode/rate controls',()=>{
 const h=read('index.html');
 for(const token of ['data-gst-mode="exclusive"','data-gst-mode="inclusive"','data-gst-rate="5"','data-gst-rate="18"','data-gst-place="same"','data-gst-place="different"','id="tax-rate"','id="tax-mode"']) assert.ok(h.includes(token),`missing ${token}`);
 assert.match(h,/class="gst-options-row"[\s\S]*?class="gst-quick-rates"[\s\S]*?class="gst-choice-row gst-place-row"/);
});
test('GST hidden compatibility select cannot appear as a second visible dropdown',()=>{
 const css=read('assets/css/screen-parity-v10020.css');
 assert.match(css,/#screen-salestax #tax-mode[\s\S]*?display:none !important/);
 assert.match(css,/#screen-salestax \.reference-hidden-control[\s\S]*?pointer-events:none !important/);
});
test('GST visual parity stylesheet loads last and is shipped/cached for Android',()=>{
 const h=read('index.html'),prep=read('scripts/prepare-android-web.mjs'),sw=read('service-worker.js');
 assert.ok(h.indexOf('all-tools-video-parity-v10025.css')>h.indexOf('tools-only.css'));
 assert.match(prep,/assets\/css\/all-tools-video-parity-v10023\.css/);
 assert.match(sw,/\.\/assets\/css\/all-tools-video-parity-v10023\.css/);
 assert.match(sw,/sa-calculator-tools-only-v10029/);
});
test('tool keypad matches circular reference controls and keeps equals tall',()=>{
 const css=read('assets/css/screen-parity-v10020.css');
 assert.match(css,/border-radius:50% !important/);
 assert.match(css,/grid-row:3 \/ span 2/);
 assert.match(css,/background:#087bff !important/);
});
test('GST mode controls are radio-like and the obsolete header action is removed',()=>{
 const css=read('assets/css/screen-parity-v10020.css');
 assert.match(css,/gst-choice-row \.gst-choice::before/);
 assert.match(css,/gst-choice-row \.gst-choice\.active::before/);
 assert.match(css,/\.reference-screen-more \{ display:none !important/);
});
