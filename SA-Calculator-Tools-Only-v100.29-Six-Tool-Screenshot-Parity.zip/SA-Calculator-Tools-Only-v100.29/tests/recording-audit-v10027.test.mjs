import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const app=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/recording-audit-v10027.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));
const sw=fs.readFileSync('service-worker.js','utf8');
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
test('v100.27 release metadata is synchronized',()=>{
 assert.equal(pkg.version,'2.0.27-v100.29'); assert.equal(pkg.androidVersionCode,1099169);
 assert.equal(manifest.version,pkg.version); assert.match(html,/2\.0\.27-v100\.29/);
 assert.match(sw,/sa-calculator-tools-only-v10029/);
});
test('all 12 requested tool screens remain in the project',()=>{
 const ids=[...html.matchAll(/class="tool-launch-item"[^>]*data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
 assert.equal(ids.length,12); assert.equal(new Set(ids).size,12);
 for(const id of ['screen-salestax','screen-loan','screen-savings','screen-salary','screen-tip','screen-sip','screen-currencies','screen-discount','screen-percent','screen-units','screen-agecalc','screen-bodymetrics']) assert.ok(html.includes(`id="${id}"`),id);
});
test('SIP panels are mutually exclusive in markup and final CSS',()=>{
 assert.match(html,/<section[^>]*hidden=""[^>]*inert=""[^>]*aria-hidden="true"[^>]*id="sip-delay-panel"/);
 assert.match(css,/#screen-viewport #screen-sip \.sip-video-form\[hidden\]\s*,/);
 assert.match(css,/#screen-viewport #screen-sip \.sip-video-form:not\(\[hidden\]\)\s*\{\s*display:flex/);
 assert.match(app,/normal\.toggleAttribute\('inert', delayMode\)/);
 assert.match(app,/delayed\.toggleAttribute\('inert', !delayMode\)/);
});
test('currency amount display preserves raw data but constrains visual overflow',()=>{
 assert.match(css,/text-overflow:ellipsis !important/);
 assert.match(css,/font-size:clamp\(14px,4\.2vw,20px\)/);
 assert.ok(html.includes('id="cur-amount"')&&html.includes('id="cur-to-amount"'));
});
test('unit converter has one category UI and functional selectors/swap',()=>{
 assert.ok(html.includes('id="unit-category-chooser"'));
 assert.ok(html.includes('id="unit-category"'));
 assert.match(css,/#screen-viewport #screen-units \.unit-category-state \{ display:none !important; \}/);
 assert.match(css,/\.unit-select-wrap \{ grid-column:2 !important; grid-row:1 !important;/);
 assert.match(css,/\.input-row>\.input-val-box,[\s\S]*?grid-column:1 !important; grid-row:1 !important;/);
 for(const id of ['unit-from','unit-to','unit-input-val','unit-result-val','btn-unit-swap']) assert.ok(html.includes(`id="${id}"`));
 assert.match(app,/f\.value = toValue;[\s\S]*t\.value = fromValue;/);
});
test('BMI unit controls and native select contrast are defined',()=>{
 for(const id of ['bmi-weight','bmi-height','bmi-gender']) assert.ok(html.includes(`id="${id}"`));
 assert.match(css,/\.bmi-unit-switch button\.active/); assert.match(css,/color-scheme:dark !important/);
});
test('all final CSS is linked, pre-cached, and copied into Android web bundle',()=>{
 assert.ok(html.includes('assets/css/final-device-parity-v10028.css'));
 assert.ok(sw.includes('./assets/css/recording-audit-v10027.css'));
 assert.ok(fs.readFileSync('scripts/prepare-android-web.mjs','utf8').includes('assets/css/final-device-parity-v10028.css'));
});
test('workflow builds expected v100.27 APK and validates artifact',()=>{
 assert.ok(workflow.includes('SA-Calculator-Tools-Only-v100.29*.zip'));
 assert.ok(workflow.includes("expected='2.0.27-v100.29'"));
 assert.ok(workflow.includes('1099169'));
 assert.ok(workflow.includes('if-no-files-found: error'));
});
