import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('tools-only stylesheet is linked after all presentation stylesheets',()=>{
 const html=read('index.html');
 const refs=[...html.matchAll(/<link[^>]+href="([^"]+\.css)"[^>]*rel="stylesheet"[^>]*\/?\s*>/g)].map(m=>m[1]);
 assert.ok(refs.includes('assets/css/tools-only.css'),'tools-only.css must be loaded by the app shell');
 assert.ok(refs.indexOf('assets/css/final-device-parity-v10029.css')===refs.length-1,'authoritative screen parity stylesheet must load last');
});
test('tools-only stylesheet is shipped and cached for Android/offline launch',()=>{
 const prep=read('scripts/prepare-android-web.mjs'), sw=read('service-worker.js');
 assert.match(prep,/assets\/css\/tools-only\.css/);
 assert.match(sw,/\.\/assets\/css\/tools-only\.css/);
 assert.match(sw,/sa-calculator-tools-only-v10029/);
});
test('legacy Home, Settings, Favorites and History are hidden in Tools-only mode',()=>{
 const css=read('assets/css/tools-only.css');
 for(const selector of ['#screen-viewport > #screen-calc','#screen-viewport > #screen-favorites','#screen-viewport > #screen-settings','#bottom-navigation','#sidebar-drawer','#history-modal']) assert.ok(css.includes(selector));
});
