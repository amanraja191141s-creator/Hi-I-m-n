import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const html = read('index.html');
const css = read('assets/css/all-tools-video-parity-v10025.css');
const priorCss = read('assets/css/all-tools-video-parity-v10023.css');
const pkg = JSON.parse(read('package.json'));
const sw = read('service-worker.js');
const app = read('assets/js/app.js');
const prep = read('scripts/prepare-android-web.mjs');
const workflow = read('.github/workflows/main.yml');

test('current release metadata and final stylesheet are connected end-to-end', () => {
  assert.equal(pkg.version, '2.0.27-v100.29');
  assert.equal(pkg.androidVersionCode, 1099169);
  assert.match(app, /APP_VERSION = '2\.0\.27-v100\.29'/);
  assert.match(html, /all-tools-video-parity-v10025\.css/);
  assert.match(sw, /all-tools-video-parity-v10025\.css/);
  assert.match(prep, /all-tools-video-parity-v10025\.css/);
  assert.match(workflow, /2\.0\.27-v100\.29/);
  assert.match(workflow, /1099169/);
});

test('aria-hidden remains an accessibility attribute rather than a visual hide mechanism', () => {
  assert.match(priorCss, /\[hidden\]\s*\{\s*display:none!important;\s*\}/);
  assert.doesNotMatch(priorCss, /\[aria-hidden="true"\][^{]*\{\s*display:none/);
});

test('Percentage legacy select is hidden while its app state remains synchronized', () => {
  assert.match(html, /class="percent-reference-mode"/);
  assert.match(css, /#screen-percent \.percent-reference-mode/);
  assert.match(css, /display: none !important/);
  assert.match(app, /percent-mode-select/);
});

test('Unit legacy category select stays in DOM but cannot render as a duplicate dropdown', () => {
  assert.match(html, /id="unit-category"/);
  assert.match(css, /\.unit-category-state/);
  assert.match(css, /display: none !important/);
  assert.doesNotMatch(html, /All categories|unit-category-back/);
  assert.match(app, /catSel\.value = category/);
});

test('computed discount results are not styled as editable input frames', () => {
  assert.match(css, /\.discount-result-row/);
  assert.match(css, /height: auto !important/);
});

test('all 12 tool launchers remain unique', () => {
  const ids = [...html.matchAll(/class="tool-launch-item"[^>]*data-tool-screen="([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 12);
  assert.equal(new Set(ids).size, 12);
});
