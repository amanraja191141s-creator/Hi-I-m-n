import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const html = read('index.html');
const css = read('assets/css/all-tools-video-parity-v10025.css');
const sw = read('service-worker.js');
const prep = read('scripts/prepare-android-web.mjs');
const pkg = JSON.parse(read('package.json'));
const workflow = read('.github/workflows/main.yml');

test('v100.25 release identity is consistent across app and Android build', () => {
  assert.equal(pkg.version, '2.0.27-v100.29');
  assert.equal(pkg.androidVersionCode, 1099169);
  assert.match(html, /2\.0\.27-v100\.29/);
  assert.match(read('assets/js/app.js'), /APP_VERSION = '2\.0\.27-v100\.29'/);
  assert.equal(JSON.parse(read('manifest.webmanifest')).version, pkg.version);
  assert.match(sw, /sa-calculator-tools-only-v10029/);
  assert.match(prep, /all-tools-video-parity-v10025\.css/);
  assert.match(workflow, /2\.0\.27-v100\.29/);
  assert.match(workflow, /1099169/);
});

test('Unit Converter legacy Category dropdown is never rendered', () => {
  assert.match(html, /class="tool-input-group unit-category-state" hidden/);
  assert.match(css, /\.unit-category-state\[hidden\][\s\S]*?display:\s*none !important/);
  assert.match(css, /\.unit-category-state:not\(\[hidden\]\)[\s\S]*?display:\s*none !important/);
  assert.doesNotMatch(html, /<button[^>]*unit-category-back[^>]*>[^<]*All categories/);
  assert.doesNotMatch(html, /unit-category-back|All categories/);
});

test('Unit Converter keeps exactly one category picker and working back navigation', () => {
  assert.equal((html.match(/data-unit-category="/g) || []).length, 11);
  assert.equal((html.match(/id="unit-category"/g) || []).length, 1);
  const app = read('assets/js/app.js');
  assert.match(app, /STATE\.currentScreen === 'units'[\s\S]*?window\.__showUnitCategories\?\.\(\)/);
  assert.match(app, /catSel\.dispatchEvent\(new Event\('change'/);
});

test('Unit From/To rows use equal responsive columns and no nested white native control', () => {
  assert.match(css, /grid-template-columns:\s*minmax\(0, 1fr\) minmax\(0, 1fr\)/);
  assert.match(css, /appearance:\s*none !important/);
  assert.match(css, /background:\s*#333 !important/);
  assert.match(css, /max-width:\s*360px/);
});

test('New authoritative stylesheet is last in HTML and included in Android web bundle/cache', () => {
  assert.ok(html.indexOf('all-tools-video-parity-v10025.css') > html.indexOf('all-tools-video-parity-v10024.css'));
  assert.match(sw, /all-tools-video-parity-v10025\.css/);
  assert.match(prep, /all-tools-video-parity-v10025\.css/);
  assert.match(workflow, /all-tools-video-parity-v10025\.css/);
});
