# SA Calculator Tools Only — v100.26

## Device screenshot corrections
- Removed the redundant `All categories` text button from the Unit Converter workspace. The existing screen toolbar back arrow already returns to the category tiles, so navigation remains available without a duplicate control.
- Kept the legacy Unit `Category` select in the DOM for the existing calculation/state code, but force-hidden it in the final stylesheet so it cannot appear beside the category tiles/workspace.
- Rebuilt Unit From/To rows as balanced two-column compound controls: unit selector + amount/result, with one outer row frame and no nested white native select surface.
- Standardized the swap control and note spacing; added narrow-screen sizing.
- Applied a final hidden-control guard for legacy GST, Percentage, Unit, Discount and Currency compatibility controls without removing their backing state/handlers.
- Bumped the service-worker cache and Android web asset list to include the final stylesheet.

## Release identity
- Package version: `2.0.24-v100.26`
- Android version code: `1099166`
- Tools retained: 12

## Validation
- `node scripts/prepare-android-web.mjs` passed (18 required assets).
- `npm run test:release` passed (115 tests).
- JavaScript syntax, YAML parsing, workflow parity and ZIP integrity checked separately.
- A GitHub-hosted Android APK build and physical-device visual comparison are not claimed as completed in this release package.
