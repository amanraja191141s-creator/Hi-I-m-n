# SA Calculator Tools Only v100.29 — six-tool screenshot parity

- Added a final responsive UI layer matching the supplied SIP, Discount, Percentage, Volume, Age and BMI screenshots.
- Standardized field geometry, spacing, focus borders, keypad workspace spacing and responsive behavior.
- Restored Volume to two tall single-frame rows with amount on the left, unit selector on the right and a centered swap control; removed the extra note layer from the visible screen.
- Removed visual-only duplicate/legacy layers in BMI and percentage; retained existing calculation handlers and unit/mode data wiring.
- Kept Age DOB/today inputs and calculation action; results remain hidden until calculation.
- Bumped app version to 2.0.27-v100.29 and Android versionCode to 1099169.
