# v100.28 — Device recording parity and final layout corrections

## Fixed from the 2026-11-27 device recording
- Unit Converter now uses one tall outer frame per From/To field, with amount on the first line and unit selector on the second; duplicate nested borders are removed.
- Unit swap control is centered between the two compound fields and remains keyboard/touch accessible.
- BMI kg/lbs and cm/in switches are positioned at the upper-right edge of their matching fields instead of floating between the header and input.
- BMI age and gender compatibility controls remain functional and visible with dark, readable styling rather than the white native WebView surface.
- Hidden SIP mode panels and hidden legacy controls continue to obey native hidden semantics.
- Final parity stylesheet is loaded last, included in Android web preparation, and precached under a fresh service-worker cache namespace.

## Build identity
- Package: `2.0.26-v100.28`
- Android versionCode: `1099168`

## Verification
- `npm run test:release`
- `npm run build:web`
- `node --check` for app and build scripts
- ZIP integrity and workflow YAML validation
- GitHub Actions is configured to build, inspect, and upload the installable debug APK.
- Final device pixel parity still requires installing the generated APK on the target phone.
