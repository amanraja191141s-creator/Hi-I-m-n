# v100.27 — Recording-driven layout and interaction fixes

## Fixed
- Enforced native `[hidden]` state in the final cascade so inactive SIP mode panels and hidden result rows cannot render.
- Kept SIP Calculator and SIP Delay Cost mutually exclusive, with tab state, accessibility attributes, and active input synchronized.
- Normalized Currency amount typography and overflow so long converted values remain readable without changing stored precision.
- Normalized Currency selectors and amount fields into a stable responsive two-column row.
- Corrected Unit Converter compound row sizing, selector placement, result alignment, swap hit area, and category state visibility.
- Corrected BMI unit switch placement, native select contrast, and field spacing.
- Corrected Loan/Saving/Tip/Discount result and input panel spacing, preserving calculation controls and legacy calculation state.
- Added focused regression coverage for all 12 tool screens, hidden panels, release metadata, source-to-Android asset parity, and workflow artifact path.

## Build identity
- Package: `2.0.25-v100.27`
- Android versionCode: `1099167`

## Verification
Run `npm run build:web` and `npm run test:release`. GitHub Actions builds and verifies the installable debug APK. Device-specific pixel parity still requires installation on the target phone.
